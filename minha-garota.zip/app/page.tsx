"use client"

import { useEffect, useState } from "react"
import Image from "next/image"
import QRCodeStyling from "qr-code-styling"

export default function ParaAlePage() {
  const [qrCode, setQrCode] = useState<QRCodeStyling | null>(null)
  const playlistUrl =
    "https://open.spotify.com/playlist/46N9FsDmfAIf1k19tOsjk7?si=AyRAaacgRhaN2mluJmkUrA&pi=QAv1OghWS96bM"

  useEffect(() => {
    const qr = new QRCodeStyling({
      width: 200,
      height: 200,
      data: typeof window !== "undefined" ? window.location.href : "",
      dotsOptions: {
        color: "#ff69b4",
        type: "rounded",
      },
      backgroundOptions: {
        color: "#0a0a0a",
      },
      cornersSquareOptions: {
        color: "#ff1493",
        type: "extra-rounded",
      },
      cornersDotOptions: {
        color: "#ff69b4",
        type: "dot",
      },
    })
    setQrCode(qr)
  }, [])

  useEffect(() => {
    if (qrCode) {
      const canvas = document.getElementById("qr-code")
      if (canvas) {
        qrCode.append(canvas)
      }
    }
  }, [qrCode])

  return (
    <div className="min-h-screen bg-black text-foreground overflow-x-hidden relative">
      {/* Dark grid pattern overlay */}
      <div className="fixed inset-0 opacity-20 pointer-events-none">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#1a1a1a_1px,transparent_1px),linear-gradient(to_bottom,#1a1a1a_1px,transparent_1px)] bg-[size:40px_40px]"></div>
      </div>

      {/* Subtle gradient overlay */}
      <div className="fixed inset-0 bg-gradient-to-br from-purple-950/20 via-black to-pink-950/20 pointer-events-none"></div>

      {/* Background animated hearts */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute animate-float-slow opacity-5"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 5}s`,
              fontSize: `${Math.random() * 30 + 20}px`,
            }}
          >
            💘
          </div>
        ))}
      </div>

      {/* Glowing orbs in background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-96 h-96 bg-pink-600/5 rounded-full blur-3xl animate-pulse-slow"></div>
        <div
          className="absolute bottom-20 right-10 w-96 h-96 bg-purple-600/5 rounded-full blur-3xl animate-pulse-slow"
          style={{ animationDelay: "2s" }}
        ></div>
        <div
          className="absolute top-1/2 left-1/2 w-96 h-96 bg-rose-600/5 rounded-full blur-3xl animate-pulse-slow"
          style={{ animationDelay: "4s" }}
        ></div>
      </div>

      <main className="relative z-10 container mx-auto px-4 py-12 max-w-4xl">
        {/* Header Section */}
        <div className="text-center mb-16 animate-fade-in">
          <div className="flex justify-center mb-8 animate-slide-in-top">
            <Image
              src="/images/copilot-image-1763939528417.png"
              alt="Casal anime realista"
              width={400}
              height={550}
              className="rounded-2xl shadow-2xl shadow-pink-500/20 hover:scale-105 transition-transform duration-500 border-2 border-pink-500/10"
              style={{ objectFit: "cover", height: "550px", width: "400px" }}
            />
          </div>

          <h1 className="text-6xl md:text-7xl font-bold mb-4 animate-scale-in text-transparent bg-clip-text bg-gradient-to-r from-pink-400 via-rose-400 to-purple-400">
            minha morena 💘
          </h1>
        </div>

        {/* Updated text blocks */}
        {/* First Text Block */}
        <div
          className="mb-12 p-8 rounded-3xl bg-gradient-to-br from-gray-900/60 to-gray-950/60 backdrop-blur-sm border border-pink-500/10 shadow-xl animate-slide-up"
          style={{ animationDelay: "0.2s" }}
        >
          <p className="text-lg leading-relaxed text-pink-100 text-center font-light">
            Eu não sei explicar quando começou. Só sei que, desde o primeiro olhar nos teus olhos escuros, alguma coisa
            em mim travou. Tipo bug de coração. Eles não são só bonitos… eles me hipnotizam. Me fazem esquecer do mundo.
            E teus lábios? Cara, eles têm um poder estranho. Toda vez que você fala, eu só penso: "Será que ela percebe
            o quanto eu quero beijar ela agora?"
          </p>
        </div>

        <div className="flex justify-center mb-12 animate-fade-in" style={{ animationDelay: "0.3s" }}>
          <Image
            src="/images/f63f161ae83736fd860eeceb07bd59f0.jpg"
            alt="Casal anime fofo"
            width={320}
            height={320}
            className="rounded-2xl shadow-2xl shadow-pink-500/20 hover:scale-105 transition-transform duration-500 border-2 border-pink-500/10"
            style={{ objectFit: "cover", height: "320px", width: "320px" }}
          />
        </div>

        {/* Second Text Block */}
        <div
          className="mb-12 p-8 rounded-3xl bg-gradient-to-br from-purple-950/60 to-gray-900/60 backdrop-blur-sm border border-purple-500/10 shadow-xl animate-slide-up"
          style={{ animationDelay: "0.4s" }}
        >
          <p className="text-lg leading-relaxed text-purple-100 text-center font-light">
            Teu cabelo curto e preto é tipo tua personalidade: marcante, linda, impossível de ignorar. E quando você me
            manda mensagem, mesmo que seja só um "oi", eu sorrio. Sério. Sorrio como se tivesse ganhado o dia. Porque
            você tem esse jeitinho carinhoso, fofo, que me desmonta. Me deixa leve. Me faz querer ser melhor.
          </p>
        </div>

        <div className="flex justify-center mb-12 animate-fade-in" style={{ animationDelay: "0.5s" }}>
          <Image
            src="/images/57a8dc51fddd3a51e90586e1349d1895.jpg"
            alt="Casal manga de mãos dadas"
            width={300}
            height={300}
            className="rounded-2xl shadow-2xl shadow-purple-500/20 hover:scale-105 transition-transform duration-500 border-2 border-purple-500/10"
            style={{ objectFit: "cover", height: "300px", width: "300px" }}
          />
        </div>

        {/* Third Text Block */}
        <div
          className="mb-12 p-8 rounded-3xl bg-gradient-to-br from-gray-900/60 to-purple-950/60 backdrop-blur-sm border border-rose-500/10 shadow-xl animate-slide-up"
          style={{ animationDelay: "0.6s" }}
        >
          <p className="text-lg leading-relaxed text-rose-100 text-center font-light mb-6">
            A gente já teve altos e baixos, né? Mas mesmo quando tudo parecia perdido, o amor puxava a gente de volta.
            Como se dissesse:
          </p>
          <p className="text-2xl font-semibold text-center text-pink-300 italic animate-pulse-slow">
            "Calma, ainda tem história pra viver."
          </p>
        </div>

        {/* Fourth Text Block */}
        <div
          className="mb-12 p-8 rounded-3xl bg-gradient-to-br from-rose-950/60 to-gray-900/60 backdrop-blur-sm border border-pink-500/10 shadow-xl animate-slide-up"
          style={{ animationDelay: "0.8s" }}
        >
          <p className="text-lg leading-relaxed text-pink-100 text-center font-light">
            E agora, tá chegando aquele dia que mudou tudo. Um ano desde que você entrou na minha vida sem pedir
            licença. Um ano que me fez entender que eu amo teu jeito de rir, de falar meu nome, de me provocar só pra
            ver minha cara. Um ano que me fez perceber que, quando você tá por perto, até o caos vira poesia.
          </p>
        </div>

        <div className="flex justify-center mb-12 animate-fade-in" style={{ animationDelay: "0.9s" }}>
          <Image
            src="/images/74d417269185687d2c9ff72225d7d8cd.jpg"
            alt="Casal chibi abraçado"
            width={300}
            height={300}
            className="rounded-2xl shadow-2xl shadow-pink-500/20 hover:scale-105 transition-transform duration-500 border-2 border-pink-500/10"
            style={{ objectFit: "cover", height: "300px", width: "300px" }}
          />
        </div>

        {/* Fifth Text Block */}
        <div
          className="mb-12 p-8 rounded-3xl bg-gradient-to-br from-purple-950/60 to-pink-950/60 backdrop-blur-sm border border-purple-500/10 shadow-xl animate-slide-up"
          style={{ animationDelay: "1s" }}
        >
          <p className="text-2xl leading-relaxed text-purple-100 text-center font-semibold">
            Te amo. Sem manual, sem lógica, sem freio.
          </p>
        </div>

        <div className="flex flex-col items-center gap-6 mb-12 animate-fade-in" style={{ animationDelay: "1.2s" }}>
          <div
            id="qr-code"
            className="bg-black p-4 rounded-2xl shadow-2xl shadow-pink-500/20 border border-pink-500/10"
          ></div>
          <a
            href={playlistUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="px-8 py-4 bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white font-semibold rounded-full shadow-lg hover:shadow-2xl hover:scale-105 transition-all duration-300 flex items-center gap-3"
          >
            <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 0C5.4 0 0 5.4 0 12s5.4 12 12 12 12-5.4 12-12S18.66 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.122-.779-.179-.899-.539-.12-.421.18-.78.54-.9 4.56-1.021 8.52-.6 11.64 1.32.42.18.479.659.301 1.02zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-1.021.6-1.141C9.6 9.9 15 10.561 18.72 12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.179-1.2-.181-1.38-.721-.18-.601.18-1.2.72-1.381 4.26-1.26 11.28-1.02 15.721 1.621.539.3.719 1.02.419 1.56-.299.421-1.02.599-1.559.3z" />
            </svg>
            Ouvir nossa Playlist
          </a>
        </div>

        {/* Footer */}
        <div className="text-center mt-16 animate-fade-in" style={{ animationDelay: "1.4s" }}>
          <p className="text-xl text-pink-300 font-light">
            ass: <span className="font-semibold text-purple-300">aquele que não consegue parar de pensar em você</span>
          </p>
        </div>
      </main>
    </div>
  )
}
